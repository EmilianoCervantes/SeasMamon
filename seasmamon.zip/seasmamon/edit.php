<?php
    function editarBloque($id,$secret){
    $datos = array(); //creamos un array
//bien ll
    //$json_string = json_encode($datos);
//bien
 //file_put_contents($file, $json_string); 
     $Block = array();   
     $bloque='{"id":"'.$id.'","hash":"'.$secret.'"}';
     
     
         $url = 'http://localhost:3001/editBlock';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $bloque);
    $output = curl_exec($ch);
    //$var_dum($bloque);
    // $bloque=$eliminado;
    //$extra = json_encode($bloque);
     //$extra= str_replace("[","",$extra);
     //$extra= str_replace("]","",$extra);
     //$extra= str_replace("},{", ",", $extra);
     //$extra=substr($extra,1,-1);
     
    $BlockFile='BlockR.json';
    file_put_contents($BlockFile, $bloque);
        
    }
    
editarBloque('Ss5MxnHqHu7kl0oa6zQHNOxZb9o2pHMs','eb37b1c715b851ba806036c996de7231581954cb4e18ddb98d7274296a89adc4');